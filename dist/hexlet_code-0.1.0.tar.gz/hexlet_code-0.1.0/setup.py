# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Brain games',
    'long_description': '\ufeff### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-49/actions)\n<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&width=435&lines=Hello%2C+I\'m+Aleksandr;And+this+is+my+first+project" alt="Typing SVG" /></a>\n\n\n\n\nName:\n "Brain-games"\n\n\n\n\nConsists of five parts/comands:\n1. brain-even\n2. brain-calc\n3. brain-gcd\n4. brain-progression\n5. brain-prime\n\n\n\n\n\nDemo:\n\n brain-even:\n \n<a href="https://asciinema.org/a/KsxAvVLowlNI1E3gAA2w4r5e5" target="_blank"><img src="https://asciinema.org/a/KsxAvVLowlNI1E3gAA2w4r5e5.svg" /></a>\n\n\n\n\n\n brain-calc:\n\n<a href="https://asciinema.org/a/xLjfTIgaa8bzGjgc71UHDhW9p" target="_blank"><img src="https://asciinema.org/a/xLjfTIgaa8bzGjgc71UHDhW9p.svg" /></a>\n\n\n\n\n brain-gcd:\n \n<a href="https://asciinema.org/a/qH1rUEphkk25Bgcew8mGMRmUw" target="_blank"><img src="https://asciinema.org/a/qH1rUEphkk25Bgcew8mGMRmUw.svg" /></a>\n\n\n\n\n brain-progression:\n \n<a href="https://asciinema.org/a/1n4LEiP1SizyOHK6uOVs9Yn9y" target="_blank"><img src="https://asciinema.org/a/1n4LEiP1SizyOHK6uOVs9Yn9y.svg" /></a>\n\n\n\n\n brain-prime:\n \n<a href="https://asciinema.org/a/eh3qLJE43mmQUblCfbZCx9UmE" target="_blank"><img src="https://asciinema.org/a/eh3qLJE43mmQUblCfbZCx9UmE.svg" /></a>\n\n \n\n',
    'author': 'Aleksandr Zhuravlev',
    'author_email': 'Alexandrzhuravlyov828@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/AleksandrZhuravlevv/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
