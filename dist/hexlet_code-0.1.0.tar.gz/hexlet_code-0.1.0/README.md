﻿### Hexlet tests and linter status:
[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-49/actions)
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&width=435&lines=Hello%2C+I'm+Aleksandr;And+this+is+my+first+project" alt="Typing SVG" /></a>




Name:
 "Brain-games"




Consists of five parts/comands:
1. brain-even
2. brain-calc
3. brain-gcd
4. brain-progression
5. brain-prime





Demo:

 brain-even:
 
<a href="https://asciinema.org/a/KsxAvVLowlNI1E3gAA2w4r5e5" target="_blank"><img src="https://asciinema.org/a/KsxAvVLowlNI1E3gAA2w4r5e5.svg" /></a>





 brain-calc:

<a href="https://asciinema.org/a/xLjfTIgaa8bzGjgc71UHDhW9p" target="_blank"><img src="https://asciinema.org/a/xLjfTIgaa8bzGjgc71UHDhW9p.svg" /></a>




 brain-gcd:
 
<a href="https://asciinema.org/a/qH1rUEphkk25Bgcew8mGMRmUw" target="_blank"><img src="https://asciinema.org/a/qH1rUEphkk25Bgcew8mGMRmUw.svg" /></a>




 brain-progression:
 
<a href="https://asciinema.org/a/1n4LEiP1SizyOHK6uOVs9Yn9y" target="_blank"><img src="https://asciinema.org/a/1n4LEiP1SizyOHK6uOVs9Yn9y.svg" /></a>




 brain-prime:
 
<a href="https://asciinema.org/a/eh3qLJE43mmQUblCfbZCx9UmE" target="_blank"><img src="https://asciinema.org/a/eh3qLJE43mmQUblCfbZCx9UmE.svg" /></a>

 

